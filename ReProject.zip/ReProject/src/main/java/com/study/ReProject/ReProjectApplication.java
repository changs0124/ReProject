package com.study.ReProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReProjectApplication.class, args);
	}

}
