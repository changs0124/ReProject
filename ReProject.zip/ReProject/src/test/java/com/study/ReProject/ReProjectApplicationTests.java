package com.study.ReProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
